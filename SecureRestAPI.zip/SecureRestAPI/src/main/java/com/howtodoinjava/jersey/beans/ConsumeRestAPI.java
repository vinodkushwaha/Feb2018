package com.howtodoinjava.jersey.beans;

//https://howtodoinjava.com/jersey/jersey-restful-client-api-authentication-example/
import java.io.IOException;
import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;
import org.glassfish.jersey.jackson.JacksonFeature;

public class ConsumeRestAPI {
	public static void main(String[] args) throws IOException
	{
	    httpGETCollectionExample();
	}
	 
	private static void httpGETCollectionExample()
	{
		/*<dependency>
		<groupId>org.glassfish.jersey.core</groupId>
		<artifactId>jersey-server</artifactId>
		<version>${jersey2.version}</version>
	</dependency>*/
	    ClientConfig clientConfig = new ClientConfig();
	 
	    //HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic("howtodoinjava", "password");
	    HttpAuthenticationFeature authenticationfeature = HttpAuthenticationFeature.basic("admin", "admin");
	    clientConfig.register( authenticationfeature) ;
	 /*   <dependency>
	    <groupId>org.glassfish.jersey.media</groupId>
	    <artifactId>jersey-media-json-jackson</artifactId>
	    <version>${jersey2.version}</version>
	</dependency> */
	    //'org.glassfish.jersey.media:jersey-media-json-jackson:2.25.1'
	    clientConfig.register(JacksonFeature.class);
	    /*
	    <dependency>
		<groupId>javax.ws.rs</groupId>
		<artifactId>javax.ws.rs-api</artifactId>
		<version>${jaxrs.version}</version>
	</dependency> */
	    Client client = ClientBuilder.newClient( clientConfig );
	    //client.target("http://localhost:8080/SecureRestAPI/rest").path("employees").path("1");
	    WebTarget webTarget = client.target("http://localhost:8080/SecureRestAPI/rest").path("employees");
	     
	    Invocation.Builder invocationBuilder =  webTarget.request(MediaType.APPLICATION_JSON);
	    Response response = invocationBuilder.get();
	    System.out.println(response.getStatus());
	    System.out.println(response.getStatusInfo());
	   
	     
	   if(response.getStatus() == 200)
	    {
	        Employees employees = response.readEntity(Employees.class);
	       List<Employee> lists = employees.getEmployeeList();
	       for (Employee employee : lists) {
	    	   System.out.println(employee.getId() +" : " + employee.getName());
		}
	        
	       /* List<Employee> listOfEmployees = employees.getEmployeeList();
	        System.out.println(Arrays.toString( listOfEmployees.toArray(new Employee[listOfEmployees.size()]) ));
	  */  
	       
	    //for POSt just for understanding
	       
	      /* Employee emp = new Employee();
	       emp.setId(1);
	       emp.setName("David Feezor");
	        
	       Invocation.Builder invocationBuilderpost =  webTarget.request(MediaType.APPLICATION_XML);
	        response = invocationBuilderpost.post(Entity.entity(emp, MediaType.APPLICATION_XML));
	    */
	    }
	}
}
