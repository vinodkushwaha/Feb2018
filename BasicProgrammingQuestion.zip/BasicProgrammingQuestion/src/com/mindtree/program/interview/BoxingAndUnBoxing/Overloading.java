package com.mindtree.program.interview.BoxingAndUnBoxing;

public class Overloading {
public static void main(String[] args) {
    Byte i = 5;
    byte k = 5;
    aMethod(i, k);
}
//remove comments all comments to get ambigues
static void aMethod(byte i, Byte k) {
    System.out.println("Inside 1");
}

/*static void aMethod(byte i, int k) {
    System.out.println("Inside 2");
}*/
/*static void aMethod(Byte i, Byte k) {
    System.out.println("Inside 3 ");
}*/
}
