package com.mindtree.linkedlist;


//Java program to find middle of linked list
class LinkedListMiddleElmnt
{
	Node head; // head of linked list


	/* Function to print middle of linked list */
	void printMiddle()
	{
		Node slow_ptr = head;
		Node fast_ptr = head;
		if (head != null)
		{
			while (fast_ptr != null && fast_ptr.next != null)
			{
				fast_ptr = fast_ptr.next.next;
				slow_ptr = slow_ptr.next;
			}
			System.out.println("The middle element is [" +
								slow_ptr.data + "] \n");
		}
	}

	/* Inserts a new Node at front of the list. */
	public void add(int new_data)
	{
		// Initialize Node only incase of 1st element
		if (head == null) {
			head = new Node(new_data);
		}
		// holding value of each obj when add method call
		Node crunchifyTemp = new Node(new_data);
		Node crunchifyCurrent = head;

		// Let's check for NPE before iterate over crunchifyCurrent
		if (crunchifyCurrent != null) {

			// starting at the head node, crawl to the end of the list and then
			// add element after last node
			while (crunchifyCurrent.getNext() != null) {
				crunchifyCurrent = crunchifyCurrent.getNext(); // it will give
																// first node
			}

			// the last node's "next" reference set to our new node
			crunchifyCurrent.setNext(crunchifyTemp);
		}
		
		/* 1 & 2: Allocate the Node &
				Put in the data
		Node new_node = new Node(new_data);

		 3. Make next of new Node as head 
		new_node.next = head;

		 4. Move the head to point to new Node 
		head = new_node;*/
	}

	/* This function prints contents of linked list
	starting from the given node */
	public void printList()
	{
		Node tnode = head.getNext();
		while (tnode != null)
		{
			System.out.print(tnode.getData()+"->");
			tnode = tnode.getNext();
		}
		System.out.println("NULL");
	}

	public static void main(String [] args)
	{
		LinkedListMiddleElmnt llist = new LinkedListMiddleElmnt();
		for (int i=5; i>0; --i)
		{
			llist.add(i);
			llist.printList();
			
		}
		llist.printMiddle();
	}
}
//This code is contributed by Rajat Mishra
