package com.mindtree.MySingleLinkedList;

public class CrunchifyLinkedListTest {
	public static CrunchifyLinkedList crunchifyList;

/*Singly linked list implementation

Singly Linked Lists are a type of data structure.
It is a type of list. In a singly linked list each node in the list stores the
contents of the node and a pointer or reference to the next node in the list. 
It does not store any pointer or reference to the previous node. 
It is called a singly linked list because each node only has a single link to another node.
To store a single linked list, you only need to store a reference or pointer to
the first node in that list.
The last node has a pointer to nothingness to indicate that it is the last node*/
	public static void main(String[] args) {
 
		// Default constructor - let's put "0" into head element.
		crunchifyList = new CrunchifyLinkedList();
 
		// add more elements to LinkedList
		crunchifyList.add("1");
		crunchifyList.add("2");
		crunchifyList.add("3");
		crunchifyList.add("4");
		crunchifyList.add("5");
 
		/*
		 * Please note that primitive values can not be added into LinkedList directly. They must be converted to their
		 * corresponding wrapper class.
		 */
		//crunchifyList.add("10",2);
		/*System.out.println("Print: crunchifyList: \t\t" + crunchifyList);
		System.out.println(".size(): \t\t\t\t" + crunchifyList.size());*/
		System.out.println(".get(3): \t\t\t\t" + crunchifyList.get(3) + " (get element at index:3 - list starts from 0)");
		/*System.out.println(".remove(2): \t\t\t\t" + crunchifyList.remove(2) + " (element removed)");
		System.out.println(".get(3): \t\t\t\t" + crunchifyList.get(3) + " (get element at index:3 - list starts from 0)");
		System.out.println(".size(): \t\t\t\t" + crunchifyList.size());
		System.out.println("Print again: crunchifyList: \t" + crunchifyList);*/
	}
 
}
