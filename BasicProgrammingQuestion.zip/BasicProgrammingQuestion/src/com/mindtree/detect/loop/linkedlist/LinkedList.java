package com.mindtree.detect.loop.linkedlist;

//Java program to detect and remove loop in linked list

class LinkedList {

 private static Node head;

private static class Node {

     private int data;
     private Node next;

    private Node(int d) {
         data = d;
         next = null;
     }
 }

 // Function that detects loop in the list
 boolean detectLoop(Node node) {
	 //create 2 pointer slow and fast to detect cycle
     Node slow = node;
     Node fast = node;
     boolean flag  = false;
     while (slow != null && fast != null && fast.next != null) {
         slow = slow.next;
         fast = fast.next.next; //looping point

         // If slow and fast meet at same point then loop is present
         if (slow == fast) {
            // removeLoop(slow, node);
        	 System.out.println("loop detected::" +slow.next.data +"::::::::::"+ fast.next.next.data);
        	 fast.next.next=null; //looping point set to be null to remove detected loop
        	 flag = true;
         }
       }
     if(flag){
    	 System.out.println("loop detected and removed");
     } else{
    	 System.out.println("loop not detected !!!!!!1");
     }
     return flag;
	
     }
  
 
 // Function that detects loop in the list
 void detectAndRemoveLoop(Node node) {
	 boolean flag = false;
     // If list is empty or has only one node
     // without loop
     if (node == null || node.next == null)
         return;

     Node slow = node;
     Node fast = node;

     // Move slow and fast 1 and 2 steps
     // ahead respectively.
     

     // Search for loop using slow and fast pointers
				     while (fast != null && fast.next != null) {
				    	 slow = slow.next;
				         fast = fast.next.next;
				         if (slow == fast) {
				        	 System.out.println("loop detected");
				        	  flag = true;
				        	 break;
				         }
				    
				     }

				     if(flag){
				    	  //        since fast->next is the looping point 
				    	///matchesssssssssssssssssssssssssss remember check above
				         fast.next.next.next = null;  //remove loop  
				     }

 }

 // Function to print the linked list
 void printList(Node node) {
     while (node != null) {
         System.out.print(node.data + " ");
         node = node.next;
     }
 }

 // Driver program to test above functions
 public static void main(String[] args) {
     LinkedList list = new LinkedList();
     list.head = new Node(50);
     list.head.next = new Node(20);
     list.head.next.next = new Node(15);
     list.head.next.next.next = new Node(4);
     list.head.next.next.next.next = new Node(10);
     list.head.next.next.next.next.next = new Node(100);

     // Creating a loop for testing 
   head.next.next.next.next.next.next = head.next.next.next;///matchesssssssssssssssssssssssssss remember check above
   // head.next.next.next.next.next = head.next;
    //  list.detectLoop(head);
    list.detectAndRemoveLoop(head);
    System.out.println("Final Linked List ");
     list.printList(head);
 }
}

//This code has been contributed by Mayank Jaiswal