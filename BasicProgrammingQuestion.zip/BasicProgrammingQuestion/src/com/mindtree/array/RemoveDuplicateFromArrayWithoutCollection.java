package com.mindtree.array;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RemoveDuplicateFromArrayWithoutCollection {


	public static void main(String args[]) {
		
		int[] input = { 1, 1, 2, 2, 3, 4, 5 };
		System.out.println("Array with Duplicates       : "
				+ Arrays.toString(input));
		
		
		System.out.println("After removing duplicates   : "
				+ Arrays.toString(removeDuplicates(input)));

	/*	int[][] test = new int[][] { { 1, 1, 2, 2, 3, 4, 5 },
				{ 1, 1, 1, 1, 1, 1, 1 }, { 1, 2, 3, 4, 5, 6, 7 },
				{ 1, 2, 1, 1, 1, 1, 1 }, };

		for (int[] input : test) {
			System.out.println("Array with Duplicates       : "
					+ Arrays.toString(input));
			System.out.println("After removing duplicates   : "
					+ Arrays.toString(removeDuplicates(input)));
		}*/
	}

	/*
	 * Method to remove duplicates from array in Java, without using Collection
	 * classes e.g. Set or ArrayList. Algorithm for this method is simple, it
	 * first sort the array and then compare adjacent objects, leaving out
	 * duplicates, which is already in the result.
	 */
	public static int[] removeDuplicates(int[] numbersWithDuplicates) {

		// Sorting array to bring duplicates together
		Arrays.sort(numbersWithDuplicates);
		int[] result = new int[numbersWithDuplicates.length];
		List<Integer> list = new ArrayList<>();
		//int[] result = new int[7];
		int previous = numbersWithDuplicates[0];
		//result[0] = previous;
		//list.add(0, previous);

		for (int i = 1; i < numbersWithDuplicates.length; i++) {
			int next = numbersWithDuplicates[i];

			if (previous != next) {
				result[i] = next;
				previous = next;
			}
			
		}
		return result;

	}
}
