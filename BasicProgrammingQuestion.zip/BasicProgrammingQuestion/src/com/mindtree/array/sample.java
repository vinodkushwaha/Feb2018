package com.mindtree.array;

public class sample {

}
