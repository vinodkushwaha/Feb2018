package com.mindtree.array;

//FInd maximum sum of contiguous element
public class MaxSubArraySum {
	public static void main(String[] args) {
		int[] a = { 3, -2, -6, 4, -1, -2, 1, 5, -3, -4 };
		int n = a.length;
		System.out.println("Maximum contiguous sum is " + maxSubArraySum(a, n));
	}

	static int maxSubArraySum(int a[], int size) {
		int max_so_far = a[0];
		int curr_max = a[0];

		for (int i = 1; i < size; i++) {
			curr_max = Math.max(a[i], curr_max + a[i]);
			max_so_far = Math.max(max_so_far, curr_max);//ignore current max if its less than max so far
			System.out.println(curr_max +":" +max_so_far );
		}
		return max_so_far;
	}
}
/*
			*   1:3
				-5:3
				4:4
				3:4
				1:4
				2:4
				7:7
				4:7
				0:7
				Maximum contiguous sum is 7
 
 * Time Complexity: O(n) Algorithmic Paradigm: Dynamic Programming
 * 
 * subArray: [4, -1, -2, 1, 5]
 * 
 * Output: Maximum contiguous sum is 7
 */