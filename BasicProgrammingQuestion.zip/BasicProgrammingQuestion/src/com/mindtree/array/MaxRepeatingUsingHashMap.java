package com.mindtree.array;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class MaxRepeatingUsingHashMap {
    public void maxRepeatingElementUsingMap(int [] arrA){
        //Will store each character and it's count
        HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
        for (int i = 0; i <arrA.length; i++) {
            if(map.containsKey(arrA[i])){
            	System.out.println("map.get(arrA[i] :" + map.get(arrA[i]));
            	int count = map.get(arrA[i]);
                map.put(arrA[i], ++count);
            }else{
                map.put(arrA[i], 1);
            }
        }

        //traverse the map and track the element which has max count
        Set<Entry<Integer, Integer>> entrysets= map.entrySet();
        Iterator<Entry<Integer, Integer>> entries =entrysets.iterator();
        
        int maxCount = 0;
        int element =0;
        while(entries.hasNext()){
           Entry<Integer, Integer> entry =entries.next();
            int count = entry.getValue();
            if(count > maxCount){
                maxCount = count;
                element = entry.getKey();
            }
        }
        System.out.println("Element repeating maximum no of times: " + element + ", maximum count: " + maxCount);
    }
    public static void main(String[] args) {
        int [] arrA = {4, 1, 5, 2, 1, 5, 9, 8, 6, 5, 3, 2, 4, 7};
        MaxRepeatingUsingHashMap m = new MaxRepeatingUsingHashMap();
        m.maxRepeatingElementUsingMap(arrA);
    }
}
