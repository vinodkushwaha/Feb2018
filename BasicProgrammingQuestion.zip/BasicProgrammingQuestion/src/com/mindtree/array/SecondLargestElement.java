package com.mindtree.array;

public class SecondLargestElement {

	public static int findSecond(int[] A) {
		int fstNo = A[0];//1
		int sndNo = -1;
		for (int i = 1; i < A.length; i++) {
			if (fstNo < A[i]) {
				sndNo = fstNo;// store the first largest number value to second
								// largest
				fstNo = A[i];
				System.out.println("fstNo : " + fstNo +"  sndNo:"+sndNo);
			} else if (sndNo < A[i]) {
				
				sndNo = A[i];
				System.out.println("fstNo : " + fstNo +"  sndNo:"+sndNo);
			}
		}
		return sndNo;
	}

	public static void main(String[] args) {
		int[] A = { 1, 2, 10, 20, 40, 32, 51, 6 };
		System.out.println("Second largest Element : " + findSecond(A));

	}

}
