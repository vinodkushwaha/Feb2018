package com.citi.exception;

import java.io.IOException;

public class Unix {

	public void whoAmI() throws Exception {
		System.out.println("I am UNIX");
	}
}
