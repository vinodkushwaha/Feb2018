package com.citi;

import java.util.HashMap;
import java.util.HashSet;

public class HashSetTest {
	public static void main(String[] args){
		
		HashSet<Employee> sets = new HashSet<Employee>();
		
		Employee e1 = new Employee("vinod",100);
		Employee e2 = new Employee("vinod",100);
		sets.add(e1);
		sets.add(e2);
		System.out.println(sets.size());
		
		HashMap<Employee,String> maps = new HashMap<>();
		maps.put(e1, "VIN");
		maps.put(e2, "VIN");
		System.out.println(maps.size());
		//if we won't implements hashcode and equals methods than Size will be 2
	}
}
