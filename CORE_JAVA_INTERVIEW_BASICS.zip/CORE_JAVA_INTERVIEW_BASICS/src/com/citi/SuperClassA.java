package com.citi;

public class SuperClassA {
	
	public void circle(){
		System.out.println("Circle Super class");
	}
	public void rectrangle(){
		System.out.println("rectrangle Super class");
	}
	public void Square(){
		System.out.println("Square Super class");
	}

}
