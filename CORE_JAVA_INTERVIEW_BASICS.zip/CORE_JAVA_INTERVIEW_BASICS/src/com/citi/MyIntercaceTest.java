package com.citi;

public class MyIntercaceTest implements MyInterfaceB, MyInterfaceA{

	
	
	public static void main(String [] args){
		
		MyInterfaceB myInterfaceB =new MyIntercaceTest();
		MyInterfaceA myInterfaceA =new MyIntercaceTest();
		MyIntercaceTest test =new MyIntercaceTest();
		myInterfaceA.add();
		myInterfaceB.add();
		test.add();
	}
	
	@Override
	public void add() {
		System.out.println("Same methods in with 2 implments");
		
	}

	@Override
	public void delete() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void multiplication() {
		// TODO Auto-generated method stub
		
	}

}
