package com.mindtree.enumEx;
//1)But yes, you can create Enum without any instance in Java, 
//2)all Enum by default extend abstract base class java.lang.Enum, 
//3)Enum by default impalement Comparable interface, they can be safely used inside TreeSet or TreeMap in Java
//4) ordinal() method, which is the natural order of Enum
//Question 5) Can we create instance of Enum outside of Enum itself? If Not, Why?
   //No, you can not create enum instances outside of Enum boundry, because Enum doesn't
/*have any public constructor, and compiler doesn't allow you to provide any 
public constructor in Enum. Since compiler generates lot of code in response to 
enum type declaration,
 it doesn�t allow public constructors inside Enum, which enforces
declaring enum instances inside Enum itself.*/
//Private constructor we can declare

public enum MessageUtil {
	
	;  // required to avoid compiler error, also signifies no instance
	public static boolean isValid() {
        throw new UnsupportedOperationException("Not supported yet.");
}
	
}
