package com.mindtree.compAndComrUsingList;

import java.util.Comparator;

public class SortByMovieYear implements Comparator<Movie> {

	@Override
	public int compare(Movie m1, Movie m2) {
		int year1 = m1.getYear();
		int year2 = m2.getYear();
		//ascending order
		//   return year1 - year2;
		   // //descending order
		   return year2 - year1;
	}

}
