package com.mindtree.hashmap.interview;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class HashMapSortingIntegerSal{ 
	public static void main(String args[]) throws ParseException {
		
		// let's create a map with Java releases and their code names 
		Map<String, Integer> codenames = new HashMap<String, Integer>(); 
		codenames.put("A", 1000);
		codenames.put("C", 10);
		codenames.put("V", 20000);
		codenames.put("G", 9000);
		codenames.put("B", 7000); 
		codenames.put("K", 4); 
		codenames.put("D", 897);
		System.out.println("HashMap before sorting, random order "); 
		Set<Entry<String, Integer>> entries = codenames.entrySet();
		for(Entry<String, Integer> entry : entries){
			System.out.println(entry.getKey() + " ==> " + entry.getValue()); 
			}

		// Now let's sort HashMap by keys first 
		// all you need to do is create a TreeMap with mappings of HashMap 
		// TreeMap keeps all entries in sorted order 
		TreeMap<String, Integer> sorted = new TreeMap<String, Integer>(codenames);
		Set<Entry<String, Integer>> mappings = sorted.entrySet(); 
		System.out.println("HashMap after sorting by Keys in ascending order"); 
		for(Entry<String, Integer> mapping : mappings) { 
			System.out.println(mapping.getKey() + " ==> " + mapping.getValue()); 
			}

		// Now let's sort the HashMap by values
		// there is no direct way to sort HashMap by values but you
		// can do this by writing your own comparator, which takes 
		// Map.Entry object and arrange them in order increasing 
		// or decreasing by values. 
		Comparator<Entry<String, Integer>> valueComparator = new Comparator<Entry<String,Integer>>() 
				{
			@Override
			public int compare(Entry<String, Integer> e1, Entry<String, Integer> e2) 
			{
				Integer v1 = e1.getValue(); 
				Integer v2 = e2.getValue(); 
				//return v1.compareTo(v2); 
				return v1 -v2;
				}
			};
			// Sort method needs a List, so let's first convert Set to List in Java 
			List<Entry<String, Integer>> listOfEntries = new ArrayList<Entry<String, Integer>>(entries);
			// sorting HashMap by values using comparator
			Collections.sort(listOfEntries, valueComparator);
			LinkedHashMap<String, Integer> sortedByValue = new LinkedHashMap<String, Integer>(listOfEntries.size());
			// copying entries from List to Map
			for(Entry<String, Integer> entry : listOfEntries)
			{
				sortedByValue.put(entry.getKey(), entry.getValue());
			} 
			System.out.println("HashMap after sorting entries by values ");
			Set<Entry<String, Integer>> entrySetSortedByValue = sortedByValue.entrySet();
			for(Entry<String, Integer> mapping : entrySetSortedByValue)
			{ 
				System.out.println(mapping.getKey() + " ==> " + mapping.getValue());
				}
			}
	}