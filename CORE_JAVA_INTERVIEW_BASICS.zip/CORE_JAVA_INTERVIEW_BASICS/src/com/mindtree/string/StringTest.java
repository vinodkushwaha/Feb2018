package com.mindtree.string;

public class StringTest {

	public static void main(String[] args) {
		//scenario 1
		String s1 = new String("pankaj");
		String s2 = new String("PANKAJ");
		System.out.println( s1 == s2);//false
		
		//scenario 2
	/*	It will print false because we are using new operator
		to create String, so it will be created in the heap memory and 
		both s1, s2 will have different reference. If we create them using double quotes, 
		then they will be part of string pool and it will print true.*/
		String s3 = new String("abc");
		String s4 = new String("abc");
		System.out.println(s3 == s4); //false
		System.out.println(s4.equals(s3));//true
		String s5 = "abc";
		String s6 = "abc";
		System.out.println(s5 == s6);//true
		System.out.println(s5.equals(s6));//true
		System.out.println("\n");
		System.out.println(s5.equals(s3));//true checking content
	System.out.println(s3 == s5);//false checking reference

	
	
	}

}
