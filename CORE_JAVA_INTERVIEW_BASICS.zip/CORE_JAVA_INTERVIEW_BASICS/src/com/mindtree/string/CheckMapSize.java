package com.mindtree.string;

import java.util.HashMap;
import java.util.Map;

public class CheckMapSize {
	
	Map<String,Integer> maps = new HashMap<>();
	CheckMapSize(){
		maps.put("vinod", 100);
		maps.put("vinod2", 101);
	}

	public static void main(String[] args) {
		CheckMapSize c = new CheckMapSize();

		System.out.println(c.orgsize());
		
	}

	private int  orgsize() {
		return maps.size();
	}

}
