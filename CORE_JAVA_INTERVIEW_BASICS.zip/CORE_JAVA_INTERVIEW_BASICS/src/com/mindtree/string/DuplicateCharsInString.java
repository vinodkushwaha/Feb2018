package com.mindtree.string;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class DuplicateCharsInString {

	public static void main(String[] args) {
		DuplicateCharsInString dcs = new DuplicateCharsInString();

		dcs.findDuplicateChars("Java2Novice");
	}

	private void findDuplicateChars(String str) {

		Map<Character, Integer> dupMap = new HashMap<Character, Integer>();
		char[] chrs = str.toCharArray();
		for (Character ch : chrs) {
			if (dupMap.containsKey(ch)) {
				dupMap.put(ch, dupMap.get(ch) + 1);
			} else {
				dupMap.put(ch, 1);
			}
		}
	/*	Set<Entry<Character,Integer>> entryset =  dupMap.entrySet();
		Iterator<Entry<Character,Integer>> iter = entryset.iterator();
		while(iter.hasNext()){
			Entry<Character,Integer> v = iter.next();
			v.getKey();
			v.getValue();
		}*/
		
		
		Set<Character> keys = dupMap.keySet();
		for (Character ch : keys) {
			if (dupMap.get(ch) > 1) {
				System.out.println(ch + "--->" + dupMap.get(ch));
			}
		}
	}
}
