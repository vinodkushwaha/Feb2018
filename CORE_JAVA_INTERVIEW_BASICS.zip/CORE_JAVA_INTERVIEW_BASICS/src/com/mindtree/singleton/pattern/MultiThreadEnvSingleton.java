package com.mindtree.singleton.pattern;

public class MultiThreadEnvSingleton {
	
    private static MultiThreadEnvSingleton instance;
   //private volatile static Singleton _instance; 
    private MultiThreadEnvSingleton(){}
  /*  Without volatile modifier it's possible for another thread in Java
    to see half initialized state of _instance variable, but with volatile variable guaranteeing happens-before relationship,
    all the write will happen on volatile _instance before any read of _instance variable.*/
    public static MultiThreadEnvSingleton getInstance(){
        if(instance == null){
        	synchronized (MultiThreadEnvSingleton.class) {
        		//double checked locking - because second check of Singleton instance with lock
        		if(instance == null){
        			instance = new MultiThreadEnvSingleton();
        		}
			}
            
        }
        return instance;
    }
    public static void main(String[] args){
    	MultiThreadEnvSingleton obj = MultiThreadEnvSingleton.getInstance();
		System.out.println("MultiThreadEnvSingleton :" + obj);
	}
}
