package com.mindtree.singleton.pattern;

public class StaticBlockSingleton {
	private static final StaticBlockSingleton instance;

	private StaticBlockSingleton() {
	}

	// static block initialization for exception handling
	static {
		try {
			instance = new StaticBlockSingleton();
		} catch (Exception e) {
			throw new RuntimeException(
					"Exception occured in creating singleton instance");
		}
	}
	public static void main(String[] args){
		StaticBlockSingleton obj = StaticBlockSingleton.getInstance();
		System.out.println("StaticBlockSingleton :" + obj);
	}
	private static StaticBlockSingleton getInstance() {
		// TODO Auto-generated method stub
		return instance;
	}

}
