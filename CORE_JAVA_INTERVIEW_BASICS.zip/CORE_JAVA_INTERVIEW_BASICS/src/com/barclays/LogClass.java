package com.barclays;

import java.util.logging.Level;
import java.util.logging.Logger;

//import org.apache.log4j.*;

public class LogClass {
 /*  private static org.apache.log4j.Logger log = Logger.getLogger(LogClass.class);
   
   public static void main(String[] args) {
      log.setLevel(Level.WARN);

      log.trace("Trace Message!");
      log.debug("Debug Message!");
      log.info("Info Message!");
      log.warn("Warn Message!");
      log.error("Error Message!");
      log.fatal("Fatal Message!");
   }
*/
}
/*op:
	Warn Message!
	Error Message!
	Fatal Message!
*/