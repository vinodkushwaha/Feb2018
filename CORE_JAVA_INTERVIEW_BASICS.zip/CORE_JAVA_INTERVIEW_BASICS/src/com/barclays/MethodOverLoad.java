package com.barclays;

public class MethodOverLoad extends Thread implements Runnable{
	@Override
	public void run() {
	    Object target;
		System.out.println();
	}
}
