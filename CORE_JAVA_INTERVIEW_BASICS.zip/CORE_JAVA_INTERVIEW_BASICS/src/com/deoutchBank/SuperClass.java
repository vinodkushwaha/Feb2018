package com.deoutchBank;

public class SuperClass {
	protected static void display(){
		System.out.println("inside super class");
	}

}
