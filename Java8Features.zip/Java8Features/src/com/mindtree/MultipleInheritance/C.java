package com.mindtree.MultipleInheritance;

public interface C extends A{
	 }

