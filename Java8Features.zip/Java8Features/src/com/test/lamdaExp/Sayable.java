package com.test.lamdaExp;

public interface Sayable {
	 public String say(String name); 
}
