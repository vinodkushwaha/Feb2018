package com.test.lamdaExp;

@FunctionalInterface
public interface Drawable {
	 public void draw();  
	 
	 //target Type must be functional interface
	 //public void display();  
}
