package com.test.lamdaExp;

public interface PersonInterface {
	
	public String getdetails(Person info);

}
